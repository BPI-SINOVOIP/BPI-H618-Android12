/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (c) 2019, The Linux Foundation. All rights reserved.
 */

#define CONFIG_SPECTRA_CAMERA_MODULE 1
#define CONFIG_CAMERA_FW_UPDATE_MODULE 1
#define CONFIG_CAMERA_GYRO_MODULE 1

