########################################################
#reboot step
#1.start-up write&read stress test
#2.sleep 5s
#3.reboot
########################################################


#!/bin/bash


#set -x

param_num=
param0=
param1=
max_times=
cnt=0
timefile=/reboot_times
filename=/etc/inittab
stress_script="/data/test/rwcheck"
process="/data/test/Run_Reboot_test-ubi.sh"
tmp=


get_times()
{
	if [ -f ${timefile} ]
	then
		cat ${timefile}
	else
		echo 0 > ${timefile}
	fi
}

set_times()
{
	echo ${cnt} > ${timefile}
}

seek_mountpoint()
{
	test_disk=$(ls /dev/ubi0* | awk '{print $NF}' | tail -1)
	if [ -n "$(mount | grep ${test_disk})" ]
	then
		mount_point=$(mount | grep ${test_disk} | awk '{print $3}')
	else
		mount_point="/mnt/`basename ${test_disk}`"
		(mkdir -p ${mount_point})
		mount -t ubifs ${test_disk} ${mount_point}
		if [$? -ne 0 ]
		then
			echo "mount ${mount_point} fail, pls check"
			exit 1
		fi

	fi
}
add_startup()
{
	### check /etc/inittab ###
	[ -e ${filename} ] || (echo "${filename} is not exist"; exit 1)

	if [ $? -eq 1 ]
	then
		exit 1
	fi

	tmp=$(cat ${filename} | grep `basename ${process}`)
	echo "tmp=$tmp"
	if [ -n "${tmp}" ]
	then
		echo "${process} item in ${filename} exist"
	else
		echo "backup ${filename} ..."
		cp ${filename} ${filename}.backup

		if [ $? -eq 0 ]
		then
			echo "backup ${filename} success"
		else
			echo "backup ${filename}fail"
			exit 1
		fi

		### tail add startup process item ###
		echo ::sysinit:${process} ${param1} >> ${filename}

	fi

}


main()
{

	## check input paramter
	if [ ${param_num} -ne 1 ]
	then
		echo "pls input as format: ${process} number"
		echo "eg. ${process} 12345"
		exit 1
	else
		expr ${param1}+1 &> /dev/null
		if [ $? -ne 0 ]
		then
			echo "pls input as format: ${process} number"
			echo "eg. ${process} 12345"
			exit 1
		fi
		echo "================== you want to test times is ${param1}  =================="
	fi


	add_startup
	seek_mountpoint

	max_times=${param1}

	cnt=`get_times`

	if [ ${cnt} -eq  0 ];then
		echo ====================================== reboot test start ... =============================================
	fi

	let cnt+=1
	set_times

	if [ ${cnt} -le  ${max_times} ];then
		chmod u+x ${stress_script}
		echo "start stress write&read"
		${stress_script} -d $mount_point -b 128k -t 99999999 &
		tmp=$(ps -e | grep 'basename ${stress_script}')
		if [ -z "${tmp}" ]
		then
			echo "write&read stress start fail \\-/"
		fi
		sleep 5
		echo ====================================== reboot times : ${cnt} =============================================
		reboot
	fi

	if [ ${cnt} -gt ${max_times} ];then
		echo ====================================== reboot test end ===================================================
		echo ====================================== total times : ${max_times} ========================================
		echo "restore ${filename}"
		cp ${filename}.backup ${filename}

	fi

}
#####################################################################################################################

param_num=$#
param0=$0
param1=$1
main
