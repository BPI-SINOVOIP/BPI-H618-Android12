#!/bin/sh
##### the last partition disk as the test disk

### test time config eg. 2 day ###
#set -x
#times unit is hour
times=48
#tim is a counter, don't modify
time=0 #

sprocess_name="/data/test/rwcheck"
dprocess_name=
mount_point=

#seek mount point
seek_mountpoint()
{
	test_disk=$(ls /dev/ubi0* | awk '{print $NF}' | tail -1)
	if [ -n "$(mount | grep ${test_disk})" ]
	then
		mount_point=$(mount | grep ${test_disk} | awk '{print $3}')
	else
		mount_point="/mnt/`$basename ${test_disk}`"
		(mkdir -p ${mount_point})
		mount -t ubifs /dev/${test_disk} ${mount_point}
		if [$? -ne 0 ]
		then
			echo "mount ${mount_point} fail, pls check"
			exit 1
		fi

	fi
}
seek_mountpoint
echo " ===================== pls retain logs ================== "
echo " ===================== pls retain logs ================== "
echo " ===================== pls retain logs ================== "

${sprocess_name} -d $mount_point -b 128k -t 999999999 &

while :
do

sleep 1h

time=$(expr ${time} + 1)

#echo time=${time}

dprocess_name=$(ps -e | grep ${sprocess_name} | head -1 | awk '{print $3}')

echo dprocess_name=${dprocess_name}

if [ "${sprocess_name}" != "${dprocess_name}" ]
then
	echo "stress test fail"
	exit
else
	if [ ${time} -eq ${times} ]
	then
		echo " ************************** stess test end ********************** "
		echo " ************************** pls check logs ********************** "
		echo ""
		killall -e ${sprocess_name}
		exit
	fi
fi
done
