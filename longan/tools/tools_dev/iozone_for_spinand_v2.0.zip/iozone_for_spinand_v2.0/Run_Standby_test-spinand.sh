##############
##
## happen standby while write & read operation
##
##############
#!/bin/bash

#### 10s standby 10s resume under stress test

stress_script="/data/test/Run_Stress_test-spinand.sh"

count=0
times=5
chmod u+x ${stress_script}
${stress_script} &
echo N > /sys/module/printk/parameters/console_suspend

while [ ${count} -lt ${times} ]
do
	let "count++"

	sleep 30
	echo +3 > /sys/class/rtc/rtc0/wakealarm
	echo mem > /sys/power/state
	sleep 3

done

