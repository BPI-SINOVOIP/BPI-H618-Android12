#############################
#1. create 80% disk size file
#2. create file md5sum >> ${filename}-${checksum_tool}
#3. if ${filename}-${tool} exist,check md5sum
#############################
#!/bin/bash

count=0
mount_point=
test_disk=
testdisk_size=
remain_disksize=0
used_rate=0
filesize=
filename="randomtxt"
filepath="/data/test"
checksum_tool="md5sum"
checksumfile=${filepath}/${filename}-${checksum_tool}
checksum=
tmpchecksum=
createfile_rate=10240

seek_mountpoint()
{
	test_disk=$(ls /dev/ubi0* | awk '{print $NF}' | tail -1)
	if [ -n "$(mount | grep ${test_disk})" ]
	then
		mount_point=$(mount | grep ${test_disk} | awk '{print $3}')
	else
		mount_point="/mnt/`basename ${test_disk}`"
		(mkdir -p ${mount_point})
		mount -t ubifs ${test_disk} ${mount_point}
		if [$? -ne 0 ]
		then
			echo "mount ${mount_point} fail, pls check"
			exit 1
		fi

	fi
}

get_testdisk_size()
{
	testdisk_size=$(df | grep ${test_disk} | awk '{print $2}') #KB
	testdisk_size=$(expr ${testdisk_size} \* 1024) #Byte
	#tmp=$(echo "scale=3;${testdisk_size}/1024/1024" | bc)# small machine not bc
	echo disk size:${testdisk_size} Bytes
}
get_testdisk_remainsize()
{
	remain_disksize=$(df | grep ${test_disk} | awk '{print $4}')
	#tmp=$(echo "scale=3;${testdisk_size}/1024/1024" | bc)
	tmp=$(expr ${remain_disksize} / 1024)
	echo "disk remain size: $tmp M"
}

get_testdisk_usedrate()
{
	used_rate=$(df -h | grep ${test_disk} | awk '{print $5}')
	used_rate=$(echo ${used_rate} | sed -e 's/%//g')
	echo "used_rate:$used_rate%"
}

main()
{
	if [ -f ${checksumfile} ]
	then

		seek_mountpoint

		checksum=$(cat ${checksumfile} | awk '{print $1}')

		tmpchecksum=$(${checksum_tool} ${mount_point}/${filename} | awk '{print $1}')

		echo $checksum
		echo $tmpchecksum
		if [ ${checksum} != ${tmpchecksum} ]
		then
			echo "High Temperature keep data test fail"
			echo "High Temperature keep data test fail"
			echo "High Temperature keep data test fail"
		else
			echo "High Temperature keep data test success"
			echo "High Temperature keep data test success"
			echo "High Temperature keep data test success"
		fi


	else
		#size=1G
		size=0

		seek_mountpoint

		get_testdisk_size

		get_testdisk_usedrate

		#keep data size for 80% of test disk
		if [ ${used_rate} -gt 20 ]
		then
			echo "keep data size for 80% of test disk , disk is not enough"
			exit 1
		fi

		echo disk size:$testdisk_size
		filesize=$(expr ${testdisk_size} / 10)
		filesize=$(expr ${filesize} \* 8)
		echo "create filesize:$filesize Bytes"

		while :
		do
			for i in {1..102400}
			do
				echo -n "${RANDOM} ${RANDOM} ${RANDOM} ${RANDOM} ${RANDOM}" >> ${mount_point}/${filename}
			done
			echo " " >> ${mount_point}/${filename}
			#get file size
			size=$(ls -l ${mount_point} | grep ${filename} | awk '{print $5}')
			if [ ${size} -ge ${filesize} ]
			then
				echo "create a file,size of ${size} byte"
				exit 0
			else
				echo "create file ${size}/${filesize}"
			fi

		done
		${checksum_tool} ${mount_point}/${filename} >> ${checksumfile}

	fi
}

############################

main
