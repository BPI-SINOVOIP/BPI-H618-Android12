
### TEST 3 TIMES ### calcu average ####
#!/bin/sh
mount_point=
ret=

seek_mountpoint()
{
	test_disk=$(ls /dev/ubi0* | awk '{print $NF}' | tail -1)
	if [ -n "$(mount | grep ${test_disk})" ]
	then
		mount_point=$(mount | grep ${test_disk} | awk '{print $3}')
	else
		mount_point="/mnt/`basename $test_disk`"
		(mkdir -p ${mount_point})
		mount -t ubifs ${test_disk} ${mount_point}
		if [$? -ne 0 ]
		then
			echo "mount ${mount_point} fail, pls check"
			exit 1
		fi

	fi
}
get_testdisk_size()
{
	ret=df | grep "mount_point" | awk '{print $2}'
}
high_capacity()
{
	spec-seq.sh $mount_point 3
	spec-rand.sh $mount_point 3
}

small_capacity()
{
	spec-tiny-seq.sh $mount_point 3
}
main ()
{
	seek_mountpoint
	get_testdisk_size
	disk_cap=${ret}

	echo "disk_cap:$disk_cap KB"

	if [ ${disk_cap} -ge 131072 ] # 128MB
	then
		high_capacity
	else
		small_capacity
	fi
}

main
