#!/bin/bash

DIR_SH=$(cd "$(dirname "$0")";pwd)
DIR_CURRENT=`pwd`
NAME_FILE_RECORD="${DIR_SH}/rebootCount.txt"
NAME_FILE_STATUS="${DIR_SH}/rebootStatus.txt"
STARTUP_FILE="/etc/init.d/rcS"
NAME_STARTUP_FILE=`basename ${STARTUP_FILE}`
NAME_CURRENT_SH=`basename $0`
NAME_CURRENT_SH=${DIR_SH}/${NAME_CURRENT_SH}
COUNT=0
COUNT_MAX=1000

set_startup_file()
{
    cp -p  ${STARTUP_FILE}   ${DIR_SH}/${NAME_STARTUP_FILE}
    sync
    echo ${NAME_CURRENT_SH} ${COUNT_MAX} >> ${STARTUP_FILE}
}

unset_startup_file()
{
    mv ${DIR_SH}/${NAME_STARTUP_FILE}  ${STARTUP_FILE}
    mv  ${NAME_FILE_RECORD}  ${NAME_FILE_STATUS}
}

record_count()
{
    if [ ! -f "${NAME_FILE_RECORD}" ];then
        count=0
        touch ${NAME_FILE_RECORD}
        set_startup_file
        reboot
    fi
    count=`cat ${NAME_FILE_RECORD}`
    let "count+=1"
    echo $count > ${NAME_FILE_RECORD}
    sync
    COUNT=${count}
    echo "rebootCount:$(($count-1))"
    echo  "$NAME_CURRENT_SH"
}

reboot_count()
{
    if [ $COUNT  -le $1 ];then
        echo "reboot now"
        reboot
    else
        unset_startup_file
    fi
}


if [ 1 -ne $# ];then
    echo "format:test_reboot_force.sh 1000"
    exit 1
else
    COUNT_MAX=$1
fi
record_count
reboot_count $1

