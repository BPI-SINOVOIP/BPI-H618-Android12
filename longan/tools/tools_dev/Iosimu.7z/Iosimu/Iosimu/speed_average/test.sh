#!/bin/bash


FILE=test.txt
FILE2=average-config

CONTENT=$(cat -E ${FILE})

test()
{
for var in $(cat -E ${FILE})
do
	echo $var
done
}

test1()
{
	cat $1  | while read line
do
	echo $line
done

}

get_mem()
{

	A[1]=`echo $1 | awk -F: '{print $1}'`
	A[2]=`echo $1 | awk -F: '{print '$2 $3'}'`
	A[3]=`echo $1 | awk -F: '{print $1}'`
	A[4]=`echo $1 | awk -F: '{print $1}'`

	echo "${A[2]}"
}

test()
{
cat $FILE2 | while read line
do
	get_mem $line
done
}

test1(){
#	echo "sdfafa"
#	echo "sdfafas"
	#grep  "READ" ${FILE2}
	echo  "1"
}

libiao="li:biao"

echo $libiao |awk -F: 'BEGIN{val="libiao"} {for(i=0; i<=NF; i++){if($i=="biao") {print $i;print $val}}} END {printf "%s",val}'
echo $libiao |awk -F: 'BEGIN{val="libiao"} {for(i=0; i<=NF; i++){if($i=="biao") {print $i;}}}'
