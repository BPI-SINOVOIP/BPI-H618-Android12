#!/bin/sh
#
# reboot platform
#
cnt_file=/mnt/reboot.cnt
reboot_times=1000
printf "*****************reboot $1\n"
case "$1" in
	start)
	if [ -e $cnt_file ]; then
		i1=`awk '{print $1}' $cnt_file`
	else
		touch $cnt_file
		i1=0
		#exit
	fi
	if [ $i1 -ge $reboot_times ];then
		printf "stop reboot test@$i1\n"
		#rm /etc/reboot.cnt
		exit
	else
		printf "continue reboot test $i1/$reboot_times\n"
	fi
	let i1++
	echo $i1 > $cnt_file
	if [ -e $cnt_file ];then
		#rwcheck -d /mnt -b 1k -t 1
		#sync
		printf "reboot now\n"
		reboot
	fi
	;;
	stop)
	;;
	restart|reload)
	;;
	*)
	;;
esac
