#!/bin/bash

PATH_SH=$(cd "$(dirname "$0")";pwd)
FILE_CONFIG=${PATH_SH}/average-config
#FILE_DATA_DEFAULT=${PATH_SH}/IO_speed.txt
FILE_DATA_DEFAULT=${PATH_SH}/IO_speed.txt
FILE_RESULT=${PATH_SH}/result.txt
FILE_RESULT_ALL=${PATH_SH}/result_all.txt
CONFIG_VALUE=$(cat  "${FILE_CONFIG}")
CONFIG_LINE=(result result result result result)
CONFIG_POS=0
CONFIG_LINE_NUM=0
#CONTENT
#content=$(cat  ${FILE_DATA_DEFAULT})
#TMP_DATA=Result

CONFIG_FUNC=(
"CONFIG_GREP"
"CONFIG_GREP"
"CONFIG_POS"
"CONFIG_DATA_GET"
)

TEST_TARGET=''

get_target()
{
	df | grep emulated >> /dev/null
	if [ $? -eq 0 ]; then
		TEST_TARGET="/data"
	else
		TEST_TARGET="/mnt/sdcard"
	fi
}

CONFIG_GET()
{
	#CONFIG_VALUE=`echo  ${CONFIG_VALUE}  | tr '$' ' '`
	CONFIG_VALUE=(${CONFIG_VALUE})
	#echo ${CONFIG_VALUE[@]}
	CONFIG_DISPLAY	${CONFIG_VALUE[@]}
}

DATA_SAVE_START()
{
	echo -n $2:$1 >> ${FILE_RESULT}
}

DATA_SAVE()
{
	echo -n :$1 >> ${FILE_RESULT}
}

DATA_CAL()
{
	tmp_content=`tail -1 ${FILE_RESULT}`
	#calculate the avereage of the io-performance
	#calculate the standard of the io-performance:average*70%
	tmp_average=`echo $tmp_content | awk -F:  'BEGIN{sum=0;num=0;unit=1;} \
				{for(i=3;i<=NF;i++){sum=sum+$i;};num=NF-2;\
					if($1=="M"){unit=1024*1024}\
					else if($1=="K"){unit=1024}\
					else{unit=1}}\
				END{printf ":::::::::average:%.2f:::::::stadard:%.2f", sum/(num)/unit, sum*0.7/num/unit}'`
	#tmp_average=`echo $tmp_content | awk  'BEGIN{sum=0;num=0;} \
	#			{for(i=2;i<=NF;i++){sum=sum+$i};num=NF-2}\
	#			END{printf "%.2f", sum/(num)}'`

	#do compare with the min io-performance standard
	is_standard=`echo "$tmp_content:$1" | awk -F: 'BEGIN{min=0;standard=0;unit=1;} \
						{min=$3;\
						for(i=3;i<=NF-1;i++){if($i<min){min=$i}};\
						standard=$NF;\
						if($1=="M"){unit=1024*1024}\
						else if($1=="K"){unit=1024}\
						else{unit=1};\
						standard=standard*unit;}\
						END{if(min<standard){printf "\nerror:*****************the item is not up to standard min:%.2f::::::::::standard:%.2f***********************", min, standard}}'`

	echo $tmp_average >> ${FILE_RESULT}
	echo  "${tmp_content}${tmp_average}${is_standard}" >> $FILE_RESULT_ALL
}

CONFIG_GREP()
{
	echo $1 | grep "$2" >> /dev/null
	if [ "$?" -eq "0" ];then
		CONFIG_LINE_NUM=$(($CONFIG_LINE_NUM+1))
		#echo $CONFIG_LINE_NUM:$1:$2
	fi
}

CONFIG_POS()
{
	echo $1 | grep "$2"  >> /dev/null
	if [ "0" -eq "$?" ];then
		#CONFIG_POS=`awk -v des_str="$2" '\
		#		 {for(i=1;i<=NF;i++){if($i==des_str){print i;print $i;break;}}}'`
		CONFIG_POS=`echo $1 | awk -v des_str="$2" 'BEGIN{} \
						{for(i=0;i<NF;i++){if($i==des_str){print i;break}}}'`
		#echo $CONFIG_LINE_NUM:$1:$2
		CONFIG_LINE_NUM=$(($CONFIG_LINE_NUM+1))
		#echo $CONFIG_LINE_NUM:$1:$2
	fi

}

CONFIG_DATA_GET()
{

	tmp=`echo $1 | awk '{print NF}'`

	if [ "$tmp" -ne "1" ];then
		tmp_data=`echo $1 | awk -v CONFIG_POS="$CONFIG_POS" '{print $CONFIG_POS}'`
		CONFIG_LINE_NUM=$(($CONFIG_LINE_NUM+1))
		#echo $CONFIG_LINE_NUM:$1:$2
		#echo tmp_data:$tmp_data
		DATA_SAVE "$tmp_data"
	fi
	#var=`awk  '{print ${$i}}'`
	#echo $var: >> data.txt
}

CONFIG_DISPLAY()
{

	for i in $*
	do
		echo  "$i"
	done
}

CONFIG_PARSE()
{
	CONFIG_LINE[0]=`echo $1 | awk -F: '{print $1}'`
	tmp=`echo $1 | awk -F: '{print $2}'`
	tmp1=`echo $1 | awk -F: '{print $3}'`
	CONFIG_LINE[1]="$tmp $tmp1"
	CONFIG_LINE[2]=`echo $1 | awk -F: '{print $4}'`
	CONFIG_LINE[3]=`echo $1 | awk -F: '{print $5}'`
	CONFIG_LINE[4]=`echo $1 | awk -F: '{print $6}'`
}

DATA_GET()
{
	CONFIG_PARSE $2
	echo CONFIG_LINE:${CONFIG_LINE[1]}
	DATA_SAVE_START "${CONFIG_LINE[1]}" "${CONFIG_LINE[3]}"
	cat $1 | while read line
	do
		#echo "${CONFIG_FUNC[$CONFIG_LINE_NUM]} $line ${CONFIG_LINE[$CONFIG_LINE_NUM]} $CONFIG_LINE_NUM"
		${CONFIG_FUNC[$CONFIG_LINE_NUM]} "$line" "${CONFIG_LINE[$CONFIG_LINE_NUM]}"
		if [ "$CONFIG_LINE_NUM" -eq "${#CONFIG_FUNC[@]}"  ];then
			CONFIG_LINE_NUM=0
		fi
	done
	DATA_CAL ${CONFIG_LINE[4]}
	#cat  ${FILE_DATA_DEFAULT}
	#content= ${content#*Result:}
	#content=(${content//$/ })
	#CONFIG_DISPLAY	${content[@]}
}

if [ "x$1" != "x" ];then
	TEST_TARGET=$1
else
	get_target
fi

FILE_DATA_DEFAULT=${TEST_TARGET}/test_tmp/my_result.txt

if [ -f ${FILE_RESULT} ];then
	rm  ${FILE_RESULT} -rf
fi
if [ -f ${FILE_RESULT_ALL} ];then
	rm  ${FILE_RESULT_ALL} -rf
fi
touch ${FILE_RESULT}
touch ${FILE_RESULT_ALL}

CONFIG_GET

for var in ${CONFIG_VALUE[@]}
do
	echo var= $var
	DATA_GET  ${FILE_DATA_DEFAULT} $var
done

cat ${FILE_RESULT_ALL}
