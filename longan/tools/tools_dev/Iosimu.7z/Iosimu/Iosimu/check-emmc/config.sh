#!/bin/bash

PATH_SH=$(cd "$(dirname "$0")";pwd)
CONFIG_FILE=${PATH_SH}/check-emmc-config

CONFIG_VALUE=(
"0:checkExtCsd:none:save_default_config"
"1:compareBoot:none:save_default_config"
"2:comparePerformance:set_iosimu_dir:save_performance_config"
"3:lifeTimeEst:none:save_default_config"
"4:writeProtectGroup:none:save_default_config"
"5:dynamicCapacity:none:save_default_config"
"15:all:set_iosimu_dir:save_performance_config"
)

OPTION_CONFIG=0
IOSIMU_DIR=""

function save_default_config()
{
	echo $1 >> $CONFIG_FILE
}

function save_performance_config()
{
	echo $1:$IOSIMU_DIR >> $CONFIG_FILE
}

function set_iosimu_dir()
{
	read -p "input the dir of the comparePerformance:" IOSIMU_DIR
}


function get_config()
{
	echo "******* check_emmc configuration *******"
	echo "******* all available configuration *******"
	tmp_func=""
	tmp_option=""
	tmp_save=""

	for var in ${CONFIG_VALUE[@]}
	do
		#tmp_value=`echo $var | awk -F: '{print $1,$2}'`
		#covert str to array
		tmp_value=`echo "$var" | tr ':' ' '`
		tmp_value=($tmp_value)
		echo "${tmp_value[0]}.${tmp_value[1]}"
		i=${tmp_value[0]}
		tmp_option[$i]=${tmp_value[1]}
		tmp_func[$i]=${tmp_value[2]}
		tmp_save[$i]=${tmp_value[3]}
	done
	read -p "input the config option:" OPTION_CONFIG
	OPTION_CONFIG=($OPTION_CONFIG)

	[ -f $CONFIG_FILE ] && rm $CONFIG_FILE -rf && touch $CONFIG_FILE

	for i in ${OPTION_CONFIG[@]}
	do
		if [ "x${tmp_func[$i]}" != "xnone" ];then
			${tmp_func[$i]}
		fi
		#save_config
		${tmp_save[$i]} ${tmp_option[$i]}
	done


}

get_config
