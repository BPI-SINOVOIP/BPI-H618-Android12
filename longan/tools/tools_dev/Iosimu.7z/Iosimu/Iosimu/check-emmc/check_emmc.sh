#!/bin/bash


PATH_SH=$(cd "$(dirname "$0")";pwd)
FILE_DATA_DEFAULT=${PATH_SH}/ext_csd.log
DEV_NUM=0
MMC_UTILS=${PATH_SH}/mmc
BLK_DEV=/dev/mmcblk${DEV_NUM}
BLK_DEV_BOOT0=${BLK_DEV}boot0
BLK_DEV_BOOT1=${BLK_DEV}boot1
EXT_CSD_CHANGED="\nname:index:defaultValue:actualValue"
CONFIG_FILE=${PATH_SH}/check-emmc-config
DEV_PATH=/sys/class/mmc_host/mmc${DEV_NUM}/
FILE_RESULT_ALL=${PATH_SH}/check_emmc_result.txt

#variable
BOOT_SIZE=0x20
MMC_MANUFACTURER="Unknown"

#name:index:func:defValue
ext_csd_reg=(
"PARTITION_CONFIG:179:get_value_by_name1:0x00"
"BOOT_CONFIG_PROT:178:get_value_by_name1:0x00"
"BOOT_BUS_CONDITIONS:177:get_value_by_name1:0x00"
"BOOT_WP:173:get_value_by_name2:0x00"
"USER_WP:171:get_value_by_name2:0x00"
"FW_CONFIG:169:get_value_by_name2:0x00"
"WR_REL_SET:167:get_value_by_name2:0x1f"
"BKOPS_EN:163:get_value_by_name2:0x00"
"RST_N_FUNCTION:162:get_value_by_name2:0x00"
"PARTTIONS_ATTRIBUTE:156:get_value_by_name2:0x00"
"PARTTIONS_SETTING_COMPLETED:155:get_value_by_name2:0x00"
"GP_SIZE_MULT_4:154:get_value_by_name2:0x00000000"
"GP_SIZE_MULT_3:151:get_value_by_name2:0x00000000"
"GP_SIZE_MULT_2:148:get_value_by_name2:0x00000000"
"GP_SIZE_MULT_1:145:get_value_by_name2:0x00000000"
"ENH_SIZE_MULT:142:get_value_by_name2:0x00000000"
"ENH_START_ADDR:139:get_value_by_name2:0x00000000"
"SEC_BAD_BLK_MGMNT:134:get_value_by_name2:0x00"
"PERIODIC_WAKEUP:131:get_value_by_name2:0x00"
"USE_NATIVE_SECTOR:62:get_value_by_name2:0x00"
"EXT_PARTITIONS_ATTRIBUTE:53:get_value_by_name2:0x00"
)

LIFE_TIME_EST_TYPE=(0x00 0x00)
PRE_EOL_INFO=0x00
VENDOR_HEALTH_REPORT=0x00
VENDOR_HEALTH_INDEX=0x00

life_time_est=(
"EXT_CSD_DEVICE_LIFE_TIME_EST_TYP_B:269:get_life_time_est:0"
"EXT_CSD_DEVICE_LIFE_TIME_EST_TYP_A:268:get_life_time_est:1"
"EXT_CSD_PRE_EOL_INFO:267:get_health_report:0"
)

#usage()
#{
#
#}
get_boot_size_by_name()
{
	tmp_value=`echo $4 | grep "\[$1:" | awk -F: '{print $2}' | awk -F\] '{print $1}'`
	if [ "$tmp_value" == "" ];then
		return 2
	fi
	#covert string to num
	BOOT_SIZE=`printf "%d" $tmp_value`
	return 0
}

get_value_by_name1()
{
	tmp_value=`echo $4 | grep "\[$1:" | awk -F: '{print $2}' | awk -F\] '{print $1}'`
	if [ "$tmp_value" == "" ];then
		return 2
	fi
	#covert string to num
	tmp_value=`printf "%d" $tmp_value`
	tmp_defValue=`printf "%d" $3`
	if [ $tmp_value -eq $tmp_defValue ]; then
		return 0
	else
		tmp_value=`printf "0x%x" $tmp_value`
		tmp_defValue=`printf "0x%x" $3`
		EXT_CSD_CHANGED="${EXT_CSD_CHANGED}\n$1:$2:$tmp_defValue:$tmp_value"
		return 1
	fi
}

get_value_by_name2()
{

	tmp_value=`echo $4 | grep "\[$1\]:" | awk -F: '{print $2}'`
	if [ "$tmp_value" == "" ];then
		return 2
	fi
	#covert string to num
	tmp_value=`printf "%d" $tmp_value`
	tmp_defValue=`printf "%d" $3`
	if [ $tmp_value -eq $tmp_defValue ]; then
		return 0
	else
		tmp_value=`printf "0x%x" $tmp_value`
		tmp_defValue=`printf "0x%x" $3`
		EXT_CSD_CHANGED="${EXT_CSD_CHANGED}\n$1:$2:$tmp_defValue:$tmp_value"
		return 1
	fi
}

check_emmc_status()
{
	flag=0
	#read the ext-csd
	echo "start to read the extcsd"
	${PATH_SH}/mmc extcsd read ${BLK_DEV} > ${PATH_SH}/ext_csd.log

	echo "start to pick the ext-csd changed up"

	for var in ${ext_csd_reg[@]}
	do
		read tmp_name tmp_index tmp_func tmp_defValue <<< `echo "$var" | awk -F: '{print $1,$2,$3,$4}'`
		#can not use pipe|,because using pipe will genarate subprocesses
		#cat $FILE_DATA_DEFAULT | while read line
		while read line
		do
			${tmp_func} ${tmp_name} ${tmp_index} ${tmp_defValue} "$line"

			if [ $? -eq 1 ];then
				flag=$(($flag+1))
				break
			elif [ $? -eq 0 ];then
				break
			fi
		done < $FILE_DATA_DEFAULT
	done

	if [ "$flag" -ne "0" ];then
		echo emmc may have been used
		echo the no of ext-csd changed:$flag
		echo -e ${EXT_CSD_CHANGED}
	else
		echo emmc may never be used!
	fi
	echo "end to pick the ext-csd changed up"
}
#CHECK_EMMC_STATUS

#
get_life_time_est()
{
	tmp_value=`echo $4 | grep "\[$1\]:" | awk -F: '{print $2}'`
	if [ "x$tmp_value" == "x" ];then
		return 2
	fi
	LIFE_TIME_EST_TYPE[$3]=$tmp_value

	return 0
}

get_health_report()
{
	tmp_value=`echo $4 | grep "\[$1\]:" | awk -F: '{print $2}'`
	tmp_value_vendor=`echo $4 | grep "\[VENDOR_HEALTH_REPORT\]:" | awk -F: '{print $2}'`
	if [ "x$tmp_value" == "x" ] && [ "x$tmp_value_vendor" == "x" ];then
		return 2
	fi

	#read cid to sure manufacturer
	#tmp_manfid=`find ${DEV_PATH} -name manfid`
	#tmp_manfid=`cat $tmp_manfid`
	#tmp_manfid=$((tmp_manfid))

	if [ "x$tmp_value" != "x" ];then
		PRE_EOL_INFO=$tmp_value
	elif [ $tmp_manfid -eq $((0x90)) ];then
		VENDOR_HEALTH_REPORT[${VENDOR_HEALTH_INDEX}]=$tmp_value_vendor
		VENDOR_HEALTH_INDEX=$((VENDOR_HEALTH_INDEX+1))
	fi

	return 1
}

mmc_life_time_est()
{
	tmp_value=`printf "%d" $1`

	case $tmp_value in
	0)
		echo "Not define"
		;;
	[1-9]|10)
		echo "$(($tmp_value-1))0%%-${tmp_value}0%% life time used"
		;;
	11)
		echo "Exceeded its max estimated life time"
		;;
	*)
		echo "Reserved"
		;;
	esac
}

#reference resources from  u-boot-2014.07/drivers/mmc/mmc.c/mmc_parse_health_report
mmc_parse_health_report()
{
	echo "start to parse emmc health report"
	flag=0
	#get the ext_csd about the health_report
	for var in ${life_time_est[@]}
	do
		read tmp_name tmp_index tmp_func tmp_defValue <<< `echo "$var" | awk -F: '{print $1,$2,$3,$4}'`
		while read line
		do
			${tmp_func} ${tmp_name} ${tmp_index} ${tmp_defValue} "$line"
			if [ $? -eq 0 ];then
				flag=1
				break
			fi
		done < $FILE_DATA_DEFAULT
	done

	if [ $flag -eq 0 ];then
		echo "not support health report and the emmc less than 5.1 point version"
		return
	fi

	#read cid to sure manufacturer
	#tmp_manfid=`find ${DEV_PATH} -name manfid`
	#tmp_manfid=`cat $tmp_manfid`
	#tmp_manfid=$((tmp_manfid))

	echo -n "EOL Info(Rev blks): "
	tmp_value=`printf "%d" $PRE_EOL_INFO`
	case $tmp_value in
	1)
		echo "Normal"
		;;
	2)
		echo "Warning, consumed 80%% of rev blocks\n"
		;;
	3)
		echo "Urgent"
		;;
	4)
		if [ $tmp_manfid -eq $((0x45)) ];then
			echo "EOL"
		else
			echo "Reserved"
		fi
		;;
	*)
		echo "Not Defined of Reserved\n"
		;;
	esac

	echo -n "Wear out (type A):"
	mmc_life_time_est ${LIFE_TIME_EST_TYPE[1]}
	echo -n "Wear out (type B):"
	mmc_life_time_est ${LIFE_TIME_EST_TYPE[0]}
	tmp_manfid=$((0x00))

	#only the HYNIX emmc
	if [ $tmp_manfid -eq $((0x90)) ];then
		echo "Runtime Bad Blk"
		#max 4 CE
		for i in {0..3}
		do
			cnt=0
			# 4 byte per CE
			for j in {0..3}
			do
				tmp=${VENDOR_HEALTH_REPORT[$((i*4+j))]}
				for k in `seq 1 $j`
				do
					tmp=$((tmp*0x100))
				done
				cnt=$((cnt+tmp))
			done
			echo -n "$cnt"
		done
		echo

		echo "Factory Bad Blk:"
		#max 4 CE
		for i in {0..3}
		do
			cnt=0
			# 4 byte per CE
			for j in {0..3}
			do
				tmp=${VENDOR_HEALTH_REPORT[$((16+i*4+j))]}
				for k in `seq 1 $j`
				do
					tmp=$((tmp*0x100))
				done
				cnt=$((cnt+tmp))
			done
			echo -n "$cnt"
		done
		echo
	fi

	echo "end to parse emmc health report"
}

#avoid the storage space less than boot-size
compare_boot_partition_2()
{
	echo "start to compare the data of the boot partition"
	flag=0
	#get the boot-size
	while read line
	do
		get_boot_size_by_name "BOOT_SIZE_MULTI" 226 0x00 "$line"
		if [ $? -eq 0 ];then
			flag=1
			break
		fi
	done < $FILE_DATA_DEFAULT

	if [ $flag -eq 0 ];then
		echo "not support boot_partition and cant get the size of the boot_partition"
		return
	fi

	#compare the metadata with metadata_128K
	for i in $(seq 0 $((BOOT_SIZE-1)))
	do
		dd if=$BLK_DEV_BOOT0 of=${PATH_SH}/boot0.data bs=128K count=1 skip=$i status=noxfer
		dd if=$BLK_DEV_BOOT1 of=${PATH_SH}/boot1.data bs=128K count=1 skip=$i status=noxfer

		diff metadata_0x00_128K ${PATH_SH}/boot0.data > /dev/null
		if [ $? -ne 0 ]; then
			echo "boot0 partition has been modified:position:$i*128K"
		fi
		diff metadata_0x00_128K ${PATH_SH}/boot1.data > /dev/null
		if [ $? -ne 0 ]; then
			echo "boot1 partition has been modified:position:$i*128K"
		fi
	done
	echo "end to compare the data of the boot partition"
}

compare_boot_partition()
{
	echo "start to compare the data of the boot partition"
	flag=0
	#get the boot-size
	while read line
	do
		get_boot_size_by_name "BOOT_SIZE_MULTI" 226 0x00 "$line"
		if [ $? -eq 0 ];then
			flag=1
			break
		fi
	done < $FILE_DATA_DEFAULT

	if [ $flag -eq 0 ];then
		echo "not support boot_partition and cant get the size of the boot_partition"
		return
	fi

	dd if=$BLK_DEV_BOOT0 of=${PATH_SH}/boot0.data bs=128K count=${BOOT_SIZE}
	dd if=$BLK_DEV_BOOT1 of=${PATH_SH}/boot1.data bs=128K count=${BOOT_SIZE}

	#merge the metadata by metadata_128K
	for i in $(seq 1 $BOOT_SIZE)
	do
		cp metadata_0x00_128K metadata_t_$i
	done
	cat  metadata_t_* > metadata
	rm metadata_t_*

	diff metadata ${PATH_SH}/boot0.data > /dev/null
	if [ $? -ne 0 ]; then
		echo "boot0 partition has been modified"
	fi

	diff metadata ${PATH_SH}/boot1.data > /dev/null
	if [ $? -ne 0 ]; then
		echo "boot1 partition has been modified"
	fi
	echo "end to compare the data of the boot partition"
}

performance_comparison()
{
	#disable cache;becaues you have to get the real data for io performance
	$MMC_UTILS cache disable $BLK_DEV
	#run_fulldisk
	${PATH_SH}/run_fulldisk_write.sh $1
	#io_performeance_test
	${PATH_SH}/Run_Performance_test.sh $1
	#calculate  the result
	${PATH_SH}/cal_average.sh $1 | tee -a ${FILE_RESULT_ALL}
}

get_write_protect_group()
{
	echo "start to get the write protect group"
	$MMC_UTILS writeprotect user get $BLK_DEV
	echo "end to get the write protect group"
}

release_write_protect_group()
{
	echo "start to release the write protect group"
	$MMC_UTILS dynamic capacity $BLK_DEV
	echo "end to release the write protect group"
}
rm -rf ${FILE_RESULT_ALL}
#get the ext-csd and create the file:ext_csd.log
${MMC_UTILS} extcsd read ${BLK_DEV} > ${FILE_DATA_DEFAULT}

while read line
do
	tmp_value=`echo "$line" | tr ':' ' '`
	tmp_value=($tmp_value)

	if [ "x${tmp_value[0]}" == "xcheckExtCsd" ];then
		#check the R/W or R/W/E ext-csd
		check_emmc_status | tee -a ${FILE_RESULT_ALL}
	elif [ "x${tmp_value[0]}" == "xcompareBoot" ];then
		#ensure boot_metadata
		compare_boot_partition_2 | tee -a ${FILE_RESULT_ALL}
	elif [ "x${tmp_value[0]}" == "xcomparePerformance" ];then
		#compare the io-performance with the min standard
		performance_comparison ${tmp_value[1]}
	elif [ "x${tmp_value[0]}" == "xlifeTimeEst" ];then
		#lifie time est and health report
		mmc_parse_health_report | tee -a ${FILE_RESULT_ALL}
	elif [ "x${tmp_value[0]}" == "xwriteProtectGroup" ];then
		#get the wp_group by cmd31,which will get the different write protection group
		get_write_protect_group | tee -a ${FILE_RESULT_ALL}
	elif [ "x${tmp_value[0]}" == "xdynamicCapacity" ];then
		#release the wp-group to improve the performance by cmd28;
		release_write_protect_group
	elif [ "x${tmp_value[0]}" == "xall" ];then
		#check the R/W or R/W/E ext-csd
		check_emmc_status | tee -a ${FILE_RESULT_ALL}
		#ensure boot_metadata
		compare_boot_partition_2 | tee -a ${FILE_RESULT_ALL}
		#lifie time est and health report
		mmc_parse_health_report | tee -a ${FILE_RESULT_ALL}
		#compare the io-performance with the min standard
		performance_comparison ${tmp_value[1]}
		#get the wp_group by cmd31,which will get the different write protection group
		get_write_protect_group | tee -a ${FILE_RESULT_ALL}
	fi
done < $CONFIG_FILE


