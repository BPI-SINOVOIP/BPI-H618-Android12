
DIR=$(busybox dirname $0)

TEST_TARGET=''

get_target()
{
	df | grep emulated >> /dev/null 
	if [ $? -eq 0 ]; then
		TEST_TARGET="/data"
	else
		TEST_TARGET="/mnt/sdcard"
	fi
}

if [ x$1 != x"" ];then
	TEST_TARGET=$1
else
	get_target
fi

TEST_DIR=${TEST_TARGET}/test_tmp
rm -rf $TEST_DIR
mkdir -p $TEST_DIR

cd $TEST_DIR

$DIR/iosimu $DIR/scripts/bit_test