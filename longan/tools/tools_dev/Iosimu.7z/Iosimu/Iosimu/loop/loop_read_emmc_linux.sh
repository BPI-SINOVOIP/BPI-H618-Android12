#!/bin/bash

echo "=========Linux: eMMC: start loop read 1G data=========="

while true; do
	echo 3 > /proc/sys/vm/drop_caches
	time dd if=/dev/block/mmcblk0 of=/dev/null bs=4096 count=262144
done
