#echo N > /sys/module/printk/parameters/console_suspend
#echo 1 > /sys/power/pm_print_times
#echo 1 > /sys/module/pm/parameters/time_to_wakeup_ms

i=0

if [ 1 -ne $# ] ;then
	echo "format: test_standby.sh 1000"
	exit 1
fi

./memtester 100M > /dev/null &
while [ $1 -ne $i ]; do
	let "i++"
	echo +15 > /sys/class/rtc/rtc0/wakealarm; echo mem > /sys/power/state
	sleep 2
done
