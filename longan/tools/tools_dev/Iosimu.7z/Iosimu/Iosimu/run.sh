
DIR=$(busybox dirname $0)

TEST_TARGET=''
TEST_READ=''
ALIGN=4096
DATAGENERATOR="colordata"

usage()
{
	NAME=$(busybox basename $0)
cat << EOF

usage: $NAME -f <TEST_FILE> -s <FILESIZE> [-p <PATTERNFILE>|-K <KEY>|-k|-c|-r] [-l <PATTERNLEN>] [-L <LOOPCOUNT>] [-t <RANDTESTTIME>] [-T <TESTTIME>] [-a <ALIGN>] [-dqn] w|r|rc|rndw|rndr|rndrc ...

	-f <TEST_FILE>: test file path
	-s <FILESIZE>:  test file size (K/M/G)
	-p <PATTERNFILE>: use pattern data generator and specify data pattern file path
	-l <PATTERNLEN>: pattetn length (K/M/G)
	-K <KEY>: use key data generator and specify key (int)
	-k: use key data generator and default key (0x691e5a0f)
	-c: use color data generator [default]
	-r: use random data generator
	-b <BUFSIZE>: data buffer size (K/M/G)
	-n: no buffer align
	-a: buffer align boundary
	-L <LOOPCOUNT>: loop count for the flow [default 1]
	-t <RANDTESTTIME>: max random test time
	-T <TESTTIME>: max test time
	-q: quiet process, do not show test details
	-d: use direct IO
	-h: show usage
	w: write
	r: read
	rc: read check
	rndw: random write (force direct IO)
	rndr: random read (force direct IO)
	rndrc: random read check (force direct IO)

EOF
	exit 1
}

echo "$@"

while getopts dqncrk:f:p:l:L:s:b:a:K:t:T: OPTION
do
	case $OPTION in
	f)
	TEST_FILE=$OPTARG
	;;
	c)
	DATAGENERATOR="colordata"
	;;
	r)
	DATAGENERATOR="randdata"
	;;
	k)
	DATAGENERATOR="keydata"
	;;
	K)
	DATAGENERATOR="keydata"
	KEY=$OPTARG
	;;
	p)
	PATTERNFILE=$OPTARG
	DATAGENERATOR="patterndata"
	;;
	l)
	PATTERNLEN=$OPTARG
	;;
	s)
	FILESIZE=$OPTARG
	;;
	q)
	QUIET=1
	;;
	d)
	DIRECT=1
	;;
	b)
	BUFSIZE=$OPTARG
	;;
	L)
	LOOPCOUNT=$OPTARG
	;;
	n)
	ALIGN=
	;;
	a)
	ALIGN=$OPTARG
	;;
	t)
	RANDTESTTIME=$OPTARG
	;;
	T)
	TESTTIME=$OPTARG
	;;
	*)
	usage
	;;
esac
done


write_param()
{
	[ -z $QUIET ] && show_details=",interval=1,show"
	if [ x$1 == x1 ]; then
		rand=',random'
		[ -z $direct_arg ] && direct_arg=",direct"
		! [ -z $RANDTESTTIME ] && time_arg=",testcount=${FILESIZE},testtime=${RANDTESTTIME}"
	fi

	cat << EOF

file path=${TEST_FILE},size=${FILESIZE}
	#˳��д
	open create,mod=0666${direct_arg}
	rw wr,package=${BUFSIZE},gettime,fsync${show_details}${rand}${align_arg}${time_arg}
	close
EOF
}

read_param()
{
	[ -z $QUIET ] && show_details=",interval=1,show"
	if [ x$1 == x1 ]; then
		rand=',random'
		[ -z $direct_arg ] && direct_arg=",direct"
		! [ -z $RANDTESTTIME ] && time_arg=",testcount=${FILESIZE},testtime=${RANDTESTTIME}"
	fi
	[ x$2 == x1 ] && check_arg=',check'

	cat << EOF

file path=${TEST_FILE},size=${FILESIZE}
	#˳���
	#�������
	cleanmem
	open mod=0666${direct_arg}
	rw rd,package=${BUFSIZE},gettime${check_arg}${show_details}${rand}${align_arg}${time_arg}
	close
EOF
}


cat << EOF > $DIR/scripts/pattern_test_param
log showlevel=3

EOF

if [ $DATAGENERATOR == "patterndata" ]; then
	if [ -z $PATTERNFILE ] || ! [ -f $PATTERNFILE ];then
		echo "Cannot accessed pattern file \"$PATTERNFILE\""
		exit 1
	fi
	! [ -z $PATTERNLEN ] && len_arg=",len=$PATTERNLEN"

	cat << EOF > $DIR/scripts/pattern_test_param
dg patterndata,path=${PATTERNFILE}${len_arg}

EOF
elif [ $DATAGENERATOR == "colordata" ]; then
	cat << EOF > $DIR/scripts/pattern_test_param
dg colordata

EOF
elif [ $DATAGENERATOR == "randdata" ]; then
	cat << EOF > $DIR/scripts/pattern_test_param
dg randdata

EOF
elif [ $DATAGENERATOR == "keydata" ]; then
	! [ -z $KEY ] && key_arg=",key=$KEY"
	cat << EOF > $DIR/scripts/pattern_test_param
dg keydata${key_arg}

EOF
else
	echo "No correct data generator spicified!"
fi


! [ -z $LOOPCOUNT ] && loopcnt_arg=",count=$LOOPCOUNT"
! [ -z $TESTTIME ] && loopdur_arg=,"duration=$TESTTIME"
cat << EOF >> $DIR/scripts/pattern_test_param
loop randseed,show${loopcnt_arg}${loopdur_arg}
EOF

[ -z $BUFSIZE ] && BUFSIZE=4K

! [ -z $DIRECT ] && direct_arg=",direct"

if ! [ -z $ALIGN ]; then
	align_arg=",align=${ALIGN}"
else
	align_arg=",noalign"
fi


for i in $@
do
	if [ $i == w ]; then
		write_param 0 >> $DIR/scripts/pattern_test_param
	elif [ $i == r ];then
		read_param 0 0 >> $DIR/scripts/pattern_test_param
	elif [ $i == rc ];then
		read_param 0 1 >> $DIR/scripts/pattern_test_param
	elif [ $i == rndw ];then
		write_param 1 >> $DIR/scripts/pattern_test_param
	elif [ $i == rndr ];then
		read_param 1 0 >> $DIR/scripts/pattern_test_param
	elif [ $i == rndrc ];then
		read_param 1 1 >> $DIR/scripts/pattern_test_param
	fi
done

cat << EOF >> $DIR/scripts/pattern_test_param
loopend
EOF

$DIR/iosimu $DIR/scripts/pattern_test_param