
#!/bin/bash

#set -x

filename="/etc/inittab"

process="/data/test/Run_PowerDown_test-ubi.sh"
#power down while stress write&read
stress_script="/data/test/Run_Stress_test-ubi.sh"



add_startup()
{
	### check /etc/inittab ###
	[ -e ${filename} ] || (echo "${filename} is not exist"; exit 1)
	if [ $? -eq 1 ]
	then
		exit 1
	fi

	#check startup intem
	tmp=$(cat ${filename} | grep ${process} | awk -F ':' '{print $NF}')
	if [ -n "$tmp" ]
	then
		echo "startup item had existed"
	else
		echo "backup ${filename} ..."
		cp ${filename} ${filename}.backup

		if [ $? -eq 0 ]
		then
			echo "backup ${filename} success"
		else
			echo "backup ${filename}fail"
			exit 1
		fi

		### tail add reboot item ###
		echo ::sysinit:${process} >> ${filename}
		echo 3 > /proc/sys/vm/drop_caches
	fi
}

main()
{
	add_startup
	##### start stress script ####
	${stress_script} &
}

###### start script ###
main
